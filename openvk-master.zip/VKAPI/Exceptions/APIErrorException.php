<?php declare(strict_types=1);
namespace openvk\VKAPI\Exceptions;

class APIErrorException extends \Exception
{}
