<?php declare(strict_types=1);
namespace openvk\Web\Models;

/* 
 * NOTICE: Please use \Chandler\Database\DBEntity directly.
 */
class_alias('\Chandler\Database\DBEntity', 'openvk\Web\Models\RowModel');
