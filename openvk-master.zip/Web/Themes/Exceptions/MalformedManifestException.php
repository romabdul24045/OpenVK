<?php declare(strict_types=1);
namespace openvk\Web\Themes\Exceptions;

final class MalformedManifestException extends \Exception
{}
