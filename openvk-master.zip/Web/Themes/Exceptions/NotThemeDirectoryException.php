<?php declare(strict_types=1);
namespace openvk\Web\Themes\Exceptions;

final class NotThemeDirectoryException extends \Exception
{}
