ALTER TABLE groups ADD COLUMN owner_comment VARCHAR(36) AFTER owner;
