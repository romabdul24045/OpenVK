ALTER TABLE `groups` ADD COLUMN `display_topics_above_wall` BOOLEAN NOT NULL DEFAULT FALSE AFTER `everyone_can_create_topics`;
